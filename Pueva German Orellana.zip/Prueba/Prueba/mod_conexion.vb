﻿Imports MySql.Data
Imports MySql.Data.Types
Imports MySql.Data.MySqlClient

Module mod_conexion
    Public cadena As String
    Public conect As New MySqlConnection

    Public Function conexion_g() As Boolean
        Dim estado As Boolean = True
        Try
            cadena = ("server=localhost;user id='root';password='';database='prueba'")
            conect = New MySqlConnection(cadena)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
            estado = False

        End Try
        Return estado
    End Function

    Public Sub cerrar()
        conect.Close()
    End Sub

End Module
