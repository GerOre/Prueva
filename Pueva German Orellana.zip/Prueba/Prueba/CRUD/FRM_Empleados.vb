﻿Public Class FRM_Empleados

    Private Sub FRM_Empleados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox5.Text = 250
        TextBox5.Enabled = False

        TextBox6.Enabled = False
        TextBox7.Enabled = False
        TextBox8.Enabled = False
        TextBox9.Enabled = False
        TextBox10.Enabled = False

        Button2.Enabled = False
        Button3.Enabled = False
        Button4.Enabled = False
        Button6.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" And TextBox2.Text = "" And TextBox3.Text = "" And TextBox4.Text = "" Then
            MsgBox("Debe ingresar todos los datos", MsgBoxStyle.Exclamation)
        Else
            Dim n_hijos, bono As Integer

            Dim igss, irtra, sueldo_b, b_paternidad, s_total, s_liquido As Double

            n_hijos = TextBox4.Text
            sueldo_b = TextBox3.Text
            bono = TextBox5.Text

            igss = (sueldo_b * 0.0483)
            irtra = (sueldo_b * 0.01)
            b_paternidad = 133 * n_hijos
            s_total = sueldo_b + b_paternidad + bono
            s_liquido = (s_total) - (igss + irtra)

            TextBox6.Text = igss
            TextBox7.Text = irtra
            TextBox8.Text = b_paternidad
            TextBox9.Text = s_total
            TextBox10.Text = s_liquido

            Button2.Enabled = True
            Button3.Enabled = True
            Button4.Enabled = True
            Button6.Enabled = True


        End If
    End Sub

 
End Class