﻿Imports MySql.Data
Imports MySql.Data.Types
Imports MySql.Data.MySqlClient
Public Class FRM_Restablecer

    Private Sub FRM_Restablecer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conexion_g()
        TextBox4.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        conect.Open()
        Dim fecha As String


        fecha = DateTimePicker1.Value.ToString("yyyy/MM/dd")

        Dim commando As MySqlCommand = New MySqlCommand
        commando.Connection = conect
        commando.CommandText = "SELECT * FROM usuarios WHERE usuario='" + TextBox2.Text + "'AND correo='" + TextBox3.Text + "' AND fecha_nac='" + fecha + "' "
        Dim reader As MySqlDataReader
        reader = commando.ExecuteReader

        If reader.HasRows <> False Then
            reader.Read()
            conect.Close()
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            TextBox4.Enabled = True
            DateTimePicker1.Enabled = False
            TextBox4.Focus()
        Else
            MsgBox("Los datos no coinciden ")
            reader.Close()
            conect.Close()
            limpiar()
        End If

    End Sub
    Private Sub limpiar()

        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox2.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim fecha As String
        fecha = DateTimePicker1.Value.ToString("yyyy/MM/dd")


        If TextBox4.Text = "" Then
            MsgBox("Ingrese una nueva contraseña !", MsgBoxStyle.Exclamation)
        Else

            Dim Str As String = "Update usuarios set password='" + TextBox4.Text + "'WHERE usuario='" + TextBox2.Text + "'AND correo='" + TextBox3.Text + "' AND fecha_nac='" + fecha + "' "
            conect.Open()
            Dim mysc2 As New MySqlCommand(Str, conect)
            mysc2.ExecuteNonQuery()
            MsgBox("Contraseña Actualizada !", MsgBoxStyle.Information)
            nuevo()
            Me.Hide()
            conect.Close()
        End If

       
    End Sub
    Private Sub nuevo()
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        DateTimePicker1.Enabled = True
        TextBox2.Focus()
        TextBox4.Enabled = False
    End Sub
End Class