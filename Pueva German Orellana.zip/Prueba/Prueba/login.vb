﻿Imports MySql.Data
Imports MySql.Data.Types
Imports MySql.Data.MySqlClient
Public Class login

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        conect.Open()
        Dim commando As MySqlCommand = New MySqlCommand

        commando.Connection = conect

        commando.CommandText = "SELECT * FROM usuarios WHERE usuario='" + TextBox1.Text + "' AND password='" + TextBox2.Text + "'"
        Dim reader As MySqlDataReader
        reader = commando.ExecuteReader
        If reader.HasRows <> False Then
            reader.Read()
            MsgBox(reader.GetString("nombre"))
            Me.Hide()
            FRM_Menu.Show()
        Else
            MsgBox("Error datos incorrectos")
            conect.Close()

        End If

    End Sub

    Private Sub login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conexion_g()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        FRM_Restablecer.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        FRM_Nuevo_Usuario.ShowDialog()
        FRM_Nuevo_Usuario.TextBox1.Focus()
    End Sub
End Class