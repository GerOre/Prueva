﻿Imports MySql.Data
Imports MySql.Data.Types
Imports MySql.Data.MySqlClient
Public Class FRM_Nuevo_Usuario

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conexion_g()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        conect.Open()

        Dim commando As MySqlCommand = New MySqlCommand
        commando.Connection = conect
        commando.CommandText = "SELECT * FROM usuarios WHERE usuario='" + TextBox2.Text + "' "
        Dim reader As MySqlDataReader
        reader = commando.ExecuteReader
        If reader.HasRows <> False Then
            reader.Read()
            MsgBox("Usuario ya existente")
            conect.Close()

        Else
            reader.Close()
            Dim cm As MySqlCommand = New MySqlCommand
            cm = New MySqlCommand("INSERT INTO usuarios (nombre, correo, usuario, fecha_nac, password) values (?nombre,?correo,?usuario,?fecha,?pass)")
            cm.Parameters.Add("?nombre", MySqlDbType.VarChar)
            cm.Parameters("?nombre").Value = TextBox1.Text
            cm.Parameters.Add("?usuario", MySqlDbType.VarChar)
            cm.Parameters("?usuario").Value = TextBox2.Text
            cm.Parameters.Add("?correo", MySqlDbType.VarChar)
            cm.Parameters("?correo").Value = TextBox3.Text
            cm.Parameters.Add("?fecha", MySqlDbType.Date)
            cm.Parameters("?fecha").Value = DateTimePicker1.Value
            cm.Parameters.Add("?pass", MySqlDbType.VarChar)
            cm.Parameters("?pass").Value = TextBox4.Text
            cm.Connection = conect
            cm.ExecuteNonQuery()
            conect.Close()
            MsgBox("Usuario guardado correctamente")
            limpiar()
        End If

    End Sub
    Private Sub limpiar()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        limpiar()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
    End Sub
End Class
